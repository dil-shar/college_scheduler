package com.shashank.platform.classroomappui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.text.Editable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class Home extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {

    TextView course;
    TextView announcement;
    TextView view_daily_schedules;
    LinearLayout profile;
    FloatingActionButton plus;
    LayoutInflater popup_inflater;
    dailySchedule ds;
    PopupWindow popupWindow;
    DBHelper dbH;
    View v;
    public ArrayList<dailySchedule> dailyScheduleArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
        plus = findViewById(R.id.plus);
        view_daily_schedules = findViewById(R.id.view_all_daily_schedules);
        dailyScheduleArrayList = new ArrayList<>();
        dbH = new DBHelper(this);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Write your needs to Admin", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        View header = navigationView.getHeaderView(0);
        profile = header.findViewById(R.id.profile);
        profile.setOnClickListener(this);
        course = findViewById(R.id.view_course);
        announcement = findViewById(R.id.view_announce);
        course.setOnClickListener(this);
        announcement.setOnClickListener(this);
        popup_inflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View popup = popup_inflater.inflate(R.layout.daily_schedule_info, null);
                Toast.makeText(getApplicationContext(), "Clicked Successfully", Toast.LENGTH_SHORT).show();
                popupWindow = new PopupWindow(popup, 1000, 2500, true);
                popupWindow.showAtLocation(findViewById(R.id.home), Gravity.CENTER_HORIZONTAL , 0, 0);

                v = popupWindow.getContentView();
                if (popupWindow.isShowing())
                    Toast.makeText(getApplicationContext(), "visible", Toast.LENGTH_SHORT).show();
                Button button = v.findViewById(R.id.add_a_schedule);
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        Toast.makeText(getApplicationContext(), "Succesesfdfasfasdf", Toast.LENGTH_LONG).show();
                        EditText course_name = v.findViewById(R.id.input_course_info);
                        EditText prof_name = v.findViewById(R.id.prof_name_text_input);
                        EditText date = v.findViewById(R.id.date_input_);
                        EditText room_no = v.findViewById(R.id.room_no_input);
                        EditText from = v.findViewById(R.id.from_input);
                        EditText to = v.findViewById(R.id.to_input);
                        ds = new dailySchedule(course_name.getText().toString(), room_no.getText().toString(), date.getText().toString(),
                                from.getText().toString() + "-" + to.getText().toString(), prof_name.getText().toString());
                        v.findViewById(R.id.prof_name_text_input);
//                        dailyScheduleArrayList.add(ds);
                        try {
                            dbH.insertDailySchedule(prof_name.getText().toString(), course_name.getText().toString(), from.getText().toString() + "-" + to.getText().toString(),
                                    date.getText().toString(), room_no.getText().toString());
                            Toast.makeText(Home.this, "Added", Toast.LENGTH_SHORT).show();
                            popupWindow.dismiss();
                        }catch (Exception e) {
                            Toast.makeText(Home.this, "Daily Schedule Not Added", Toast.LENGTH_SHORT).show();
                            popupWindow.dismiss();
                        }
                    }
                });


            }
        });
        view_daily_schedules.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent open_daily_schedules = new Intent(getApplicationContext(), dailySchedulesView.class);
                startActivity(open_daily_schedules);
            }
        });


    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement


        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_courses) {
            Intent intent = new Intent(getApplicationContext(), Courses.class);
            startActivity(intent);
        } else if (id == R.id.nav_events) {
            Intent intent = new Intent(getApplicationContext(), Events.class);
            startActivity(intent);

        } else if (id == R.id.nav_lectures) {
            Intent intent = new Intent(getApplicationContext(), Lectures.class);
            startActivity(intent);
        } else if (id == R.id.nav_announcements) {
            Intent intent = new Intent(getApplicationContext(), Announcements.class);
            startActivity(intent);
        } else if (id == R.id.nav_settings) {
            Intent intent = new Intent(getApplicationContext(), Settings.class);
            startActivity(intent);

        } else if (id == R.id.nav_logout) {
            finish();
        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_rate) {

        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.profile) {
            Intent intent = new Intent(getApplicationContext(), MyProfile.class);
            startActivity(intent);
        } else if (view.getId() == R.id.view_course) {
            Intent intent = new Intent(getApplicationContext(), Courses.class);
            startActivity(intent);
        } else if (view.getId() == R.id.view_announce) {
            Intent intent = new Intent(getApplicationContext(), Announcements.class);
            startActivity(intent);
        }
    }
}
