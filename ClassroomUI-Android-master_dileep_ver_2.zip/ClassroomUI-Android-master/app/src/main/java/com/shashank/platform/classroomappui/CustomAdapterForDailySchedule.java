package com.shashank.platform.classroomappui;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class CustomAdapterForDailySchedule extends BaseAdapter {
    private Context context;
    private ArrayList<dailySchedule> dailyScheduleArrayList;
    private TextView date,from_to,prof,course,room_no;
    ImageButton delete;
    int position;
    DBHelper dbHelper;
    ListView lv ;
    public CustomAdapterForDailySchedule(Context context, ArrayList<dailySchedule> arrayList) {

        this.context = context;
        this.dailyScheduleArrayList = arrayList;

    }

    @Override
    public int getCount() {
        return dailyScheduleArrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int pos, View view, ViewGroup parent) {
       view  = LayoutInflater.from(context).inflate(R.layout.row_for_daily_schedule,parent,false);
       course = view.findViewById(R.id.course_name);
       prof = view.findViewById(R.id.prof_name);
       date = view.findViewById(R.id.date);
       from_to = view.findViewById(R.id.from_to_time);
       room_no = view.findViewById(R.id.room_no);
       delete = view.findViewById(R.id.delete_row_daily_schedule);
       lv = (ListView) view.getParent();

        position = pos;
       delete.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               dbHelper = new DBHelper(context);

               int id = dbHelper.getIdOfSchedule(dailyScheduleArrayList.get(position),context);
               dbHelper.deleteDailySchedule(id,context);
               CustomAdapterForDailySchedule.this.notifyDataSetChanged();
              notifyDataSetChanged();


           }
       });
       course.setText(dailyScheduleArrayList.get(pos).getCourseName());
       prof.setText(dailyScheduleArrayList.get(pos).getProfessor_name());
       from_to.setText(dailyScheduleArrayList.get(pos).getFrom_to());
       date.setText(dailyScheduleArrayList.get(pos).getDate());
       room_no.setText(dailyScheduleArrayList.get(pos).getClassN0());

//       return view;

         return view;
    }
}
