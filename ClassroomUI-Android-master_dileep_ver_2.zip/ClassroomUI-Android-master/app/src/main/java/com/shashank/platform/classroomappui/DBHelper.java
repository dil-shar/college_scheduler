package com.shashank.platform.classroomappui;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "MyDBName.db";
    public static final String DAILY_SCHEDULE_TABLE_NAME = "daily_schedule";
    public static final String DAILY_SCHEDULE_COLUMN_ID = "id";
    public static final String DAILY_SCHEDULE_CONTENTS_COLUMN = "dscontents";
    public static final String DAILY_SCHEDULE_COLUMN_PROF_NAME = "profName";
    public static final String DAILY_SCHEDULE_TABLE_COURSE_TITLE = "courseName";
    public static final String DAILY_SCHEDULE_TABLE_TIMINGS = "timings";
    public static final String DAILY_SCHEDULE_TABLE_DATE = "date";
    public static final String DAILY_SCHEDULE_TABLE_ROOM_NO = "roomNo";


    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "create table daily_schedule" +
                        "(id integer primary key, profName String,courseName String,timings String,date String,roomNo String)"
        );
//        db.execSQL(
//                "create table daily_schedlule" +
//                        "(id integer primary key,complete_info dailySchedule)"
//        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int old_ver, int new_ver) {
        db.execSQL("DROP TABLE IF EXISTS daily_schedule");
        onCreate(db);
    }

    public boolean insertDailySchedule(String pname, String cname, String tim, String date, String roomNo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("profName", pname);
        contentValues.put("courseName", cname);
        contentValues.put("timings", tim);
        contentValues.put("date", date);
        contentValues.put("roomNo", roomNo);
        db.insert("daily_schedule", null, contentValues);

        return true;
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("select * from daily_schedule where id=" + id + "", null);
    }

    public int numberOfRows() {
        SQLiteDatabase db = this.getReadableDatabase();
        return (int) DatabaseUtils.queryNumEntries(db, DAILY_SCHEDULE_TABLE_NAME);
    }

    public boolean updateDailySchedule(Integer id, String pname, String cname, String tim, String date, String roomNo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("profName", pname);
        contentValues.put("courseName", cname);
        contentValues.put("timings", tim);
        contentValues.put("date", date);
        contentValues.put("roomNo", roomNo);
        db.update("daily_schedule", contentValues, "id = ?", new String[]{Integer.toString(id)});
        return true;
    }

    public ArrayList<dailySchedule> getAllDailySchedules() {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<dailySchedule> lis = new ArrayList<>();
//        String[] columns = new String[]{DAILY_SCHEDULE_COLUMN_ID,DAILY_SCHEDULE_CONTENTS_COLUMN,DAILY_SCHEDULE_COLUMN_PROF_NAME,DAILY_SCHEDULE_TABLE_COURSE_TITLE,
//                DAILY_SCHEDULE_TABLE_TIMINGS,DAILY_SCHEDULE_TABLE_DATE,DAILY_SCHEDULE_TABLE_ROOM_NO};
////        Cursor res = db.query(DAILY_SCHEDULE_TABLE_NAME,columns,null,null,null,null, null);
        Cursor res = db.rawQuery("select * from daily_schedule", null);
        res.moveToFirst();
        int count = 0;
        while (!res.isAfterLast()) {
            res.moveToNext();
            count++;
        }


        res.moveToFirst();
        dailySchedule[] ret = new dailySchedule[count];
        for (int i = 0; i < count; i++) {
            ret[i] = new dailySchedule();
            ret[i].setProfessor_name(res.getString(res.getColumnIndex(DAILY_SCHEDULE_COLUMN_PROF_NAME)));

            res.moveToNext();
        }

        res.moveToFirst();
        for (int i = 0; i < count; i++) {
            ret[i].setCourseName(res.getString(res.getColumnIndex(DAILY_SCHEDULE_TABLE_COURSE_TITLE)));
            res.moveToNext();
        }

        res.moveToFirst();
        for (int i = 0; i < count; i++) {
            ret[i].setFrom_to(res.getString(res.getColumnIndex(DAILY_SCHEDULE_TABLE_TIMINGS)));
            res.moveToNext();
        }

        res.moveToFirst();
        for (int i = 0; i < count; i++) {
            ret[i].setDate(res.getString(res.getColumnIndex(DAILY_SCHEDULE_TABLE_DATE)));
            res.moveToNext();
        }

        res.moveToFirst();
        for (int i = 0; i < count; i++) {
            ret[i].setFrom_to(res.getString(res.getColumnIndex(DAILY_SCHEDULE_TABLE_ROOM_NO)));
            res.moveToNext();
        }
        res.moveToFirst();
        for (int i = 0; i < count; i++) {
            ret[i].setClassN0(res.getString(res.getColumnIndex(DAILY_SCHEDULE_TABLE_ROOM_NO)));
            res.moveToNext();
        }
//        while (!res.isAfterLast()) {
//            dailySchedule temp = new dailySchedule();
//            temp.setCourseName(res.getString(res.getColumnIndex(DAILY_SCHEDULE_TABLE_COURSE_TITLE)));
//            temp.setProfessor_name(res.getString(res.getColumnIndex(DAILY_SCHEDULE_COLUMN_PROF_NAME)));
//            temp.setClassN0(res.getString(res.getColumnIndex(DAILY_SCHEDULE_TABLE_ROOM_NO)));
//            temp.setDate(res.getString(res.getColumnIndex(DAILY_SCHEDULE_TABLE_DATE)));
//            temp.setFrom_to(res.getString(res.getColumnIndex(DAILY_SCHEDULE_TABLE_TIMINGS)));
//            lis.add(temp);
//
//        }
        for (int i = 0; i < count; i++) lis.add(ret[i]);
        return lis;
    }

    public int deleteDailySchedule(Integer id,Context context) {

        SQLiteDatabase db = this.getWritableDatabase();
        Toast.makeText(context, "Id is "+id, Toast.LENGTH_SHORT).show();
        return db.delete("daily_schedule", "id = ? ", new String[]{Integer.toString(id)});
    }

    public Integer getIdOfSchedule(dailySchedule ds,Context context) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from daily_schedule", null);
        res.moveToFirst();
        while (!res.isAfterLast()) {
            if (res.getString(res.getColumnIndex(DAILY_SCHEDULE_TABLE_COURSE_TITLE)).equals(ds.getCourseName()) &&
     res.getString(res.getColumnIndex(DAILY_SCHEDULE_COLUMN_PROF_NAME)).equals(ds.getProfessor_name()) &&
            res.getString(res.getColumnIndex(DAILY_SCHEDULE_TABLE_ROOM_NO)).equals(ds.getClassN0())
            ){
                return Integer.parseInt(res.getString(res.getColumnIndex(DAILY_SCHEDULE_COLUMN_ID)));
            }
            res.moveToNext();
        }

        Toast.makeText(context, "Failed to get the id", Toast.LENGTH_SHORT).show();
        return -1;
    }
}
